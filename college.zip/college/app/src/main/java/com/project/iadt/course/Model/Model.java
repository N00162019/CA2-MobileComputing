package com.project.iadt.coarse.Model;

import android.app.Application;

import com.project.iadt.coarse.Model.api.API;
import com.project.iadt.coarse.Model.api.APIListener;
import com.project.iadt.coarse.Model.api.AbstractAPIListener;
import com.project.iadt.coarse.Model.api.WebAPI;

import java.util.ArrayList;
import java.util.List;

public class Model {

    private static Model sInstance = null;

    private final API mApi;
    private User mUser;
    private List<Enrolment> mEnrolments;
    private List<Course> mCourses;
    private List<Student> mStudents;


    public static Model getInstance(Application application) {
        if (sInstance == null) {
            sInstance = new Model(application);
        }
        return sInstance;
    }

    private final Application mApplication;

    private Model(Application application) {
        mApplication = application;
        mApi = new WebAPI(mApplication, this);
        mEnrolments = new ArrayList<>();
        mCourses = new ArrayList<>();
        mStudents = new ArrayList<>();
    }

    public Application getApplication() {
        return mApplication;
    }

    public void login(String email, String password, APIListener listener) {
        mApi.login(email, password, listener);
    }

    public User getUser() {
        return mUser;
    }

    public void setUser(User user) {
        this.mUser = user;
    }

    public List<Enrolment> getEnrolments() {
        return mEnrolments;
    }

    // Enrolment id is retrieved
    public Enrolment findEnrolmentById(int enrolmentId) {
        Enrolment enrolment = null;

        for (Enrolment v : mEnrolments) {
            if (v.getId() == enrolmentId) {
                enrolment = v;
                break;
            }
        }
        return enrolment;
    }

    public void storeEnrolment(Enrolment enrolment) {
        mEnrolments.add(enrolment);
    }

    public void storeEnrolment(Enrolment enrolment, AbstractAPIListener apiListener) {
        mApi.storeEnrolment(enrolment, apiListener);
    }

    // Uses API to load up the enrolments & invokes/notifies listener object after they have been loaded
    public void loadEnrolments(APIListener listener) {
        mApi.loadEnrolments(listener);
    }

    public void updateEnrolment(Enrolment enrolment, AbstractAPIListener apiListener) {
        mApi.storeEnrolment(enrolment, apiListener);
    }

    public void deleteEnrolment(Enrolment deletedEnrolment) {
        mEnrolments.remove(deletedEnrolment);
    }

    public void deleteEnrolment(Enrolment enrolment, AbstractAPIListener apiListener) {
        mApi.deleteEnrolment(enrolment, apiListener);
    }

    public List<Course> getCourses() {
        return mCourses;
    }

    public Course findCourseById(int courseId) {
        Course course = null;

        for (Course v : mCourses) {
            if (v.getId() == courseId) {
                course = v;
                break;
            }
        }
        return course;
    }

    public void addCourses(List<Course> courses) {
        mCourses.clear();
        mCourses.addAll(courses);
    }

    public void loadCourses(AbstractAPIListener listener) {
        mApi.loadCourses(listener);
    }

    public List<Student> getStudents() {
        return mStudents;
    }

    public Student findStudentById(int studentId) {
        Student student = null;

        for (Student v : mStudents) {
            if (v.getId() == studentId) {
                student = v;
                break;
            }
        }
        return student;
    }

    public void addStudents(List<Student> students) {
        mStudents.clear();
        mStudents.addAll(students);
    }

    public void loadStudents(AbstractAPIListener listener) {
        mApi.loadStudents(listener);
    }
}
