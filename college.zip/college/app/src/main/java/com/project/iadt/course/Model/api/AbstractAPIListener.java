package com.project.iadt.coarse.Model.api;

import com.project.iadt.coarse.Model.Course;
import com.project.iadt.coarse.Model.Enrolment;
import com.project.iadt.coarse.Model.Student;
import com.project.iadt.coarse.Model.User;

import java.util.List;

// Implements API listener interface
public class AbstractAPIListener implements APIListener {
    @Override
    public void onLogin(User user) {
    }

    @Override
    public void onEnrolmentsLoaded(List<Enrolment> enrolments) {

    }

    @Override
    public void onEnrolmentStored(Enrolment storedEnrolment) {

    }

    @Override
    public void onEnrolmentUpdated(Enrolment updatedEnrolment) {

    }

    @Override
    public void onEnrolmentDeleted(Enrolment deletedEnrolment) {

    }

    @Override
    public void onCoursesLoaded(List<Course> courses) {

    }

    @Override
    public void onStudentsLoaded(List<Student> students) {

    }
}
