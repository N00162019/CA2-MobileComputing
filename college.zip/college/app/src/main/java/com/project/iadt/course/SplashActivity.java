package com.project.iadt.coarse;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {

    @Override
    // Called when the activity is first created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Defines/sets the typeface
        TextView txtBrand = findViewById(R.id.txtBrand);
        Typeface face = Typeface.createFromAsset(getAssets(), "fonts/LibreBarcode39ExtendedText-Regular.ttf");
        txtBrand.setTypeface(face);

        // New handler to start the welcome activity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Creates an intent that will start the welcome activity
                startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
            }
        }, 5 * 1000); // 5 seconds delay
    }
}
