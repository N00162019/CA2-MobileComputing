package com.project.iadt.coarse;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

// RegisterActivity is defined - extends AppCompatActivity inheriting its behavior and methods.
public class RegisterActivity extends AppCompatActivity {

    @Override
    // Defines onCreate - state of the application is saved in a bundle
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
