package com.project.iadt.coarse;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

// EnrolmentsActivity is defined - extends AppCompatActivity inheriting its behavior and methods.
public class EnrolmentActivity extends AppCompatActivity {
    @Override

    // Defines onCreate - state of the application is saved in a bundle
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrolment);

        // Data is retrieved using getIntent in the new activity:
        Intent intent = getIntent();
        int enrolmentId = intent.getIntExtra(EnrolmentFragment.ARG_ENROLMENT_ID, 0);

        // Makes the app animation when replacing the Fragment
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        EnrolmentFragment fragment = EnrolmentFragment.newInstance(enrolmentId);
        ft.add(R.id.visit_container, fragment);
        ft.commit();
    }
}
