package com.project.iadt.coarse;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.project.iadt.coarse.Model.Enrolment;
import com.project.iadt.coarse.Model.Model;
import com.project.iadt.coarse.Model.api.AbstractAPIListener;

import java.util.List;

// Creates an instance of EnrolmentsFragment & returns it
public class EnrolmentsFragment extends Fragment {

    public static EnrolmentsFragment newInstance() {
        EnrolmentsFragment fragment = new EnrolmentsFragment();
        return fragment;
    }

    private OnFragmentInteractionListener mListener;

    // Constructor
    public EnrolmentsFragment() {
    }

    @Override
    // This method is called when a fragment is created
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    // In the View object, an instance is created for the enrolments fragment layout file
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_enrolments, container, false);
    }

    @Override
    // References the view created above
    public void onViewCreated(View view, Bundle savedInstanceState) {
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;
            recyclerView.setLayoutManager(new LinearLayoutManager(context));

            // Puts a divider between each row in the recycler view
            DividerItemDecoration decoration = new DividerItemDecoration(context, DividerItemDecoration.VERTICAL);
            recyclerView.addItemDecoration(decoration);

            // Referencing the application object
            Application application = this.getActivity().getApplication();

            // This is then used to get a reference to the model object
            Model model = Model.getInstance(application);
            // From the model object the list of enrolments is retrieved to display
            final List<Enrolment> enrolments = model.getEnrolments();

            // Adapter for the recycler view
            // The constructor takes reference to the required parameters
            final EnrolmentsAdapter adapter = new EnrolmentsAdapter(this, enrolments);
            recyclerView.setAdapter(adapter);

            model.loadEnrolments(new AbstractAPIListener() {
                @Override
                public void onEnrolmentsLoaded(List<Enrolment> loadedEnrolments) {
                    enrolments.clear();
                    enrolments.addAll(loadedEnrolments);
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }

    // Notifies when an enrolment has been selected
    public void onItemSelected(Enrolment enrolment) {
        if (mListener != null) {
            // This method is defined in the interface
            mListener.onItemSelected(enrolment);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    // When the fragment is removed from the activity, mListener is set to null
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onItemSelected(Enrolment enrolment);
    }
}

