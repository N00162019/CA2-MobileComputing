package com.project.iadt.coarse;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.project.iadt.coarse.Model.Course;
import com.project.iadt.coarse.Model.Enrolment;
import com.project.iadt.coarse.Model.Model;
import com.project.iadt.coarse.Model.Student;
import com.project.iadt.coarse.Model.api.AbstractAPIListener;

import java.util.List;

// EnrolmentFragment is defined - extends Fragment class inheriting its behavior and methods.
public class EnrolmentFragment extends Fragment {

    public static final String ARG_ENROLMENT_ID = "enrolment_id";

    // newInstance takes in enrolment id to be displayed
    public static EnrolmentFragment newInstance(int enrolmentId) {
        // Create empty fragment
        EnrolmentFragment fragment = new EnrolmentFragment();
        // Creates bundle
        Bundle args = new Bundle();
        // Enrolment id is placed into bundle
        args.putInt(ARG_ENROLMENT_ID, enrolmentId);
        // Set arguments for fragment
        fragment.setArguments(args);
        // Fragment is returned
        return fragment;
    }

    // Declare variables
    private EditText mDateText;
    private EditText mTimeText;
    private Spinner mCoursesSpinner;
    private Spinner mStudentsSpinner;
    private RadioButton mRegisteredButton;
    private RadioButton mAttendingButton;
    private RadioButton mDeferredButton;
    private RadioButton mWithdrawnButton;
    private Model mModel;
    private int mEnrolmentId;
    private Enrolment mEnrolment;
    // Initialised to false
    private boolean mEditmode;

    // Empty constructor
    public EnrolmentFragment() {

    }

    @Override
    // Calls method from the superclass
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Verify if arguments are present
        if (getArguments() != null) {
            // Retrieves args and enrolment id
            Bundle arguments = getArguments();
            mEnrolmentId = arguments.getInt(ARG_ENROLMENT_ID);

            // Reference to model object
            mModel = Model.getInstance(this.getActivity().getApplication());
            // If there is no enrolment id
            if (mEnrolmentId == 0) {
                // Empty enrolment object
                mEnrolment = new Enrolment(0, "", "", 0, 0, Enrolment.REGISTERED);
            } else {
                // Enrolment id retrieved
                mEnrolment = mModel.findEnrolmentById(mEnrolmentId);
            }
            // Displays menu items on action bar
            setHasOptionsMenu(true);
        }
    }

    @Override

    // Called after onCreate
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_enrolment, container, false);
    }

    @Override
    // Called after the view has been created
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mDateText = view.findViewById(R.id.dateText);
        mTimeText = view.findViewById(R.id.timeText);
        mCoursesSpinner = view.findViewById(R.id.coursesSpinner);
        mStudentsSpinner = view.findViewById(R.id.studentsSpinner);
        mRegisteredButton = view.findViewById(R.id.radio_registered);
        mAttendingButton = view.findViewById(R.id.radio_attending);
        mDeferredButton = view.findViewById(R.id.radio_deferred);
        mWithdrawnButton = view.findViewById(R.id.radio_withdrawn);

        populateForm();

        if (mEnrolmentId == 0) {
            setEditMode(true);
        } else {
            setEditMode(false);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.action_bar_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem edit = menu.findItem(R.id.action_edit);

        if (mEditmode) {
            edit.setIcon(R.drawable.ic_save_white_48dp);
            edit.setTitle("Save");
        } else {
            edit.setIcon(R.drawable.ic_edit_white_48dp);
            edit.setTitle("Edit");
        }
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    // Executed for the menu items
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_edit: {
                if (mEditmode) {
                    // Retrieves information from the form
                    Enrolment enrolment = getFormData();
                    if (mEnrolmentId == 0) {
                        storeEnrolment(enrolment);
                    } else {
                        updateEnrolment(enrolment);
                    }
                } else {
                    // If EditMode is false toast message is printed
                    Toast.makeText(getActivity(), "Edit Selected", Toast.LENGTH_LONG).show();
                }
                // Toggles the value of EditMode
                setEditMode(!mEditmode);
                // Changes pencil icon
                getActivity().invalidateOptionsMenu();
                return false;
            }
            case R.id.action_delete: {
                mModel.deleteEnrolment(mEnrolment, new AbstractAPIListener() {
                    @Override
                    public void onEnrolmentDeleted(Enrolment deletedEnrolment) {
                        if (deletedEnrolment == null) {
                            Toast.makeText(getActivity(), "Enrolment not deleted", Toast.LENGTH_LONG).show();
                        } else {
                            mModel.deleteEnrolment(deletedEnrolment);

                            Toast.makeText(getActivity(), "Enrolment not deleted", Toast.LENGTH_LONG).show();

                            EnrolmentFragment.this.getActivity().finish();
                        }
                    }
                });
                return false;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    // Strores the enrolment data
    private void storeEnrolment(Enrolment enrolment) {
        // Specifies the abstract API object
        mModel.storeEnrolment(enrolment, new AbstractAPIListener() {
            @Override
            public void onEnrolmentStored(Enrolment storedEnrolment) {
                // If the object is equal to null
                if (storedEnrolment == null) {
                    // Display a problem storing the enrolment
                    Toast.makeText(getActivity(), "Enrolment not stored", Toast.LENGTH_LONG).show();
                } else {
                    setEnrolment(storedEnrolment);
                    mModel.storeEnrolment(mEnrolment);
                    Toast.makeText(getActivity(), "Enrolment Stored", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void updateEnrolment(Enrolment enrolment) {
        // Specifies the abstract API object
        mModel.updateEnrolment(enrolment, new AbstractAPIListener() {
            @Override
            public void onEnrolmentUpdated(Enrolment updatedEnrolment) {
                if (updatedEnrolment == null) {
                    Toast.makeText(getActivity(), "Enrolment not Updated", Toast.LENGTH_LONG).show();
                } else {
                    setEnrolment(updatedEnrolment);
                    Toast.makeText(getActivity(), "Enrolment Updated", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // Takes data from enrolment object & displays it on the form
    private void populateForm() {
        // Gets/Displays date and time for the enrolment
        mDateText.setText(mEnrolment.getDate());
        mTimeText.setText(mEnrolment.getTime());

        // Gets list of courses & puts them in the spinner
        populateCourseSpinner();
        populateStudentSpinner();

        // Checks the status of the enrolment
        mRegisteredButton.setChecked(mEnrolment.getStatus().equals(Enrolment.REGISTERED));
        mAttendingButton.setChecked(mEnrolment.getStatus().equals(Enrolment.ATTENDING));
        mDeferredButton.setChecked(mEnrolment.getStatus().equals(Enrolment.DEFERRED));
        mWithdrawnButton.setChecked(mEnrolment.getStatus().equals(Enrolment.WITHDRAWN));
    }

    private void populateCourseSpinner() {
        // Gets list of courses from the model object
        List<Course> courses = mModel.getCourses();
        // Specifies list of items displayed in the spinner
        final ArrayAdapter<Course> coursesAdapter = new ArrayAdapter<>(
                this.getActivity(), android.R.layout.simple_spinner_item, courses);
        coursesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mCoursesSpinner.setAdapter(coursesAdapter);

        if (courses.size() == 0) {
            // Courses are loaded from the rest API
            mModel.loadCourses(new AbstractAPIListener() {
                @Override
                // Invokes this method on the listener object
                public void onCoursesLoaded(List<Course> courseList) {
                    if (courseList != null && !courseList.isEmpty()) {
                        // Executed after the list of courses has returned from the rest API
                        mModel.addCourses(courseList); // Adds to the list
                        coursesAdapter.notifyDataSetChanged(); // Informs the adapter that the dataset has changed
                        mCoursesSpinner.setSelection(coursesAdapter.getPosition(mEnrolment.getCourse()));
                    }
                }
            });
        } else {
            // Selects the correct course in the course spnner
            mCoursesSpinner.setSelection(coursesAdapter.getPosition(mEnrolment.getCourse()));
        }
    }

    private void populateStudentSpinner() {
        List<Student> students = mModel.getStudents();
        final ArrayAdapter<Student> studentsAdapter = new ArrayAdapter<>(
                this.getActivity(), android.R.layout.simple_spinner_item, students);
        studentsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mStudentsSpinner.setAdapter(studentsAdapter);

        if (students.size() == 0) {
            // Students are loaded from the rest API
            mModel.loadStudents(new AbstractAPIListener() {
                @Override
                // Invokes this method on the listener object
                public void onStudentsLoaded(List<Student> studentList) {
                    if (studentList != null && !studentList.isEmpty()) {
                        // Executed after the list of students has returned from the rest API
                        mModel.addStudents(studentList); // Adds to the list
                        studentsAdapter.notifyDataSetChanged(); // Informs the adapter that the dataset has changed
                        mStudentsSpinner.setSelection(studentsAdapter.getPosition(mEnrolment.getStudent()));
                    }
                }
            });
        } else {
            mStudentsSpinner.setSelection(studentsAdapter.getPosition(mEnrolment.getStudent()));
        }
    }

    private void setEditMode(boolean editMode) {
        mEditmode = editMode;
        mDateText.setEnabled(editMode);
        mTimeText.setEnabled(editMode);
        mCoursesSpinner.setEnabled(editMode);
        mStudentsSpinner.setEnabled(editMode);
        mRegisteredButton.setEnabled(editMode);
        mAttendingButton.setEnabled(editMode);
        mDeferredButton.setEnabled(editMode);
        mWithdrawnButton.setEnabled(editMode);
    }

    private Enrolment getFormData() {
        // Gets id for new enrolment created/edited
        int id = mEnrolment.getId();
        String date = mDateText.getText().toString();
        String time = mTimeText.getText().toString();
        Course course = (Course) mCoursesSpinner.getSelectedItem();
        int courseId = course.getId();
        Student student = (Student) mStudentsSpinner.getSelectedItem();
        int studentId = student.getId();
        String status = getFormStatus();

        Enrolment enrolment = new Enrolment(id, date, time, courseId, studentId, status);
        enrolment.setCourse(course);
        enrolment.setStudent(student);

        return enrolment;
    }

    private String getFormStatus() {
        String status = null;
        if (mRegisteredButton.isChecked()) {
            status = Enrolment.REGISTERED;
        } else if (mAttendingButton.isChecked()) {
            status = Enrolment.ATTENDING;
        } else if (mDeferredButton.isChecked()) {
            status = Enrolment.DEFERRED;
        } else if (mWithdrawnButton.isChecked()) {
            status = Enrolment.WITHDRAWN;
        }
        return status;
    }

    private void setEnrolment(Enrolment enrolment) {
        mEnrolment.setId(enrolment.getId());
        mEnrolment.setDate(enrolment.getDate());
        mEnrolment.setTime(enrolment.getTime());
        mEnrolment.setCourse(enrolment.getCourse());
        mEnrolment.setStudent(enrolment.getStudent());
        mEnrolment.setStatus(enrolment.getStatus());
        Course course = mModel.findCourseById(enrolment.getCourseId());
        mEnrolment.setCourse(course);
        Student student = mModel.findStudentById(enrolment.getStudentId());
        mEnrolment.setStudent(student);
    }
}
