package com.project.iadt.coarse;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

// WelcomeActivity is defined - extends AppCompatActivity inheriting its behavior and methods.
public class WelcomeActivity extends AppCompatActivity {

    // Declaring sign-in & sign-up buttons
    Button btnSignIn, btnSignUp;

    @Override
    // Called when the activity is first created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        btnSignIn = findViewById(R.id.btnSignIn);
        btnSignUp = findViewById(R.id.btnSignUp);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // launches the signup activity
                Intent signUp = new Intent(WelcomeActivity.this, RegisterActivity.class);
                startActivity(signUp);
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // launches the signin activity
                Intent signIn = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(signIn);
            }
        });
    }
}
