package com.project.iadt.coarse.Model.api;

import com.project.iadt.coarse.Model.Course;
import com.project.iadt.coarse.Model.Enrolment;
import com.project.iadt.coarse.Model.Student;
import com.project.iadt.coarse.Model.User;

import java.util.List;

// Interface implemented by listener objects
public interface APIListener {
    void onLogin(User user);

    void onEnrolmentsLoaded(List<Enrolment> enrolments);
    void onEnrolmentStored(Enrolment storedEnrolment);
    void onEnrolmentUpdated(Enrolment updatedEnrolment);
    void onEnrolmentDeleted(Enrolment deletedEnrolment);

    void onCoursesLoaded(List<Course> courses);
    void onStudentsLoaded(List<Student> students);

}
